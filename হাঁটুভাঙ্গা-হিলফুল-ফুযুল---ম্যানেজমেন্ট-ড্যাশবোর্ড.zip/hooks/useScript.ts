
import { useState, useEffect } from 'react';

export const useScript = (src: string | null) => {
  const [status, setStatus] = useState(src ? "loading" : "idle");

  useEffect(() => {
    if (!src) {
      setStatus("idle");
      return;
    }

    let script = document.querySelector(`script[src="${src}"]`) as HTMLScriptElement;
    if (!script) {
      script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.setAttribute("data-status", "loading");
      document.body.appendChild(script);

      const setState = (event: Event) => {
        const newStatus = event.type === "load" ? "ready" : "error";
        script.setAttribute("data-status", newStatus);
        setStatus(newStatus);
      };

      script.addEventListener("load", setState);
      script.addEventListener("error", setState);

      return () => {
        if (script) {
          script.removeEventListener("load", setState);
          script.removeEventListener("error", setState);
        }
      };
    } else {
      const currentStatus = script.getAttribute("data-status") as "loading" | "ready" | "error" | null;
      setStatus(currentStatus || "ready");
    }
  }, [src]);

  return status;
};
