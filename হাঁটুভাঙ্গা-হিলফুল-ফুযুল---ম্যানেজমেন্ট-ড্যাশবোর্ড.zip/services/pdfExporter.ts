
// This declares the global variables that will be available after the scripts are loaded.
declare global {
    interface Window {
        jspdf: any;
        NotoSansBengali: string;
    }
}
interface Column {
    key: string;
    header: string;
}

export const exportToPdf = (columns: Column[], data: any[], title: string) => {
  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    if (typeof window.NotoSansBengali !== 'undefined') {
       doc.addFileToVFS('NotoSansBengali-Regular.ttf', window.NotoSansBengali);
       doc.addFont('NotoSansBengali-Regular.ttf', 'NotoSansBengali', 'normal');
       doc.setFont('NotoSansBengali');
    } else {
      console.warn("Bengali font not loaded. PDF may not render correctly.");
      doc.setFont('helvetica', 'normal');
    }

    doc.setFontSize(16);
    doc.text(title, 14, 20);
    
    doc.setFontSize(10);

    const tableColumns = columns.map(col => col.header);
    const tableRows = data.map(row => columns.map(col => {
      const value = row[col.key];
      if (col.key === 'joma' || col.key === 'amount') {
        return `${(Number(value) || 0).toLocaleString('bn-BD')} ৳`;
      }
      return value !== undefined && value !== null ? value.toString() : 'N/A';
    }));

    doc.autoTable({
      head: [tableColumns],
      body: tableRows,
      startY: 25,
      styles: {
        font: 'NotoSansBengali',
        fontStyle: 'normal',
      },
      headStyles: {
        fillColor: [30, 41, 59],
        textColor: 255,
        fontStyle: 'bold',
      },
      alternateRowStyles: {
        fillColor: [241, 245, 249],
      }
    });

    doc.save(`${title.replace(/ /g, '_')}.pdf`);
  } catch (err) {
    console.error("PDF export failed:", err);
    alert("PDF এক্সপোর্ট করা যায়নি। লাইব্রেরি লোড হতে সমস্যা হয়েছে।");
  }
};
